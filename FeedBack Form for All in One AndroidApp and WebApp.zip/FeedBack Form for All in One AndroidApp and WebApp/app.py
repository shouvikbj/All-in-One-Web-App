import os
import smtplib
from flask import Flask,flash,render_template,redirect,request,url_for
import csv

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/send feedback",methods = ["POST"])
def message():
    name = request.form.get("name")
    email = request.form.get("email")
    subject = request.form.get("subject")
    message = request.form.get("message")
    if not name or not email or not subject or not message:
        flash('Please Fill All Fields')
    file = open("feedbacks.csv","a")
    writer = csv.writer(file)
    writer.writerow((name,email,subject,message))
    file.close()
    message1 = "Thank You for your Feedback regarding \"All in One\" App. Your feedback is sincerely noted and being looked upon. Enjoy using this App. Thank you from Shouvik Bajpayee."
    message2 = "Someone has given feedback regarding All in One.. Check now.."
    server = smtplib.SMTP("smtp.gmail.com", 587)
    server.ehlo()
    server.starttls()

    server.login('shouvikbajpayee.private@gmail.com', 'maathakur60@')
    server.sendmail('shouvikbajpayee.private@gmail.com', email, message1)
    server.sendmail('shouvikbajpayee.private@gmail.com', 'shouvikbajpayee.private@gmail.com', message2)
    server.close()
    return redirect("https://shouvikbj.pythonanywhere.com")

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5001, debug=True)